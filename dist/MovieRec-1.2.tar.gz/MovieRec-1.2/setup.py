from distutils.core import setup
setup(name = "MovieRec",
      version = "1.2",
      py_modules = ['movierec'],
      packages = ['modules']
      )